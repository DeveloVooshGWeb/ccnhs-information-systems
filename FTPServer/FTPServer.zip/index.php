<?php
include("server.php");
$Server = new Server;
$Server->Start();
$Server->CreateAccount("Jomari", "8197", 12, "growtopiaflipaclip@yahoo.com", "18197secured81971");
$Server->LoginAccount("Jomari", "8197");
?>

<!Doctype HTML>
<html>
<head>
<title>ccnhsisdnsserver1 infinityfree.net</title>
<link rel="stylesheet" href="everyfont.css" />
</head>
<style>
* {
font-size: 20px;
}

body {
text-align: center;
}
</style>
<body>
</body>
<script>
</script>
</html>